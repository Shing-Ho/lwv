<?php

return [
    'news' => 'News',
    'events' => 'Events',
];
