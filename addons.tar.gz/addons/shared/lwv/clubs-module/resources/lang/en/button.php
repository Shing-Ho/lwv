<?php

return [
    'new_club' => 'New Club',
    'new_document' => 'New Document',
    'new_photo' => 'New Photo',
    'new_header' => 'New Header',
    'new_post' => 'New Post',
    'website' => 'Website',
    'documents' => 'Documents',
    'photos' => 'Photos',
    'news' => 'News',
    'events' => 'Events',
    'manage' => 'Manage Website',
    'preview' => 'Preview Site',
];
