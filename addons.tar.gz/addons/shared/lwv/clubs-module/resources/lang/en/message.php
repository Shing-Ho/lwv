<?php

return [
    'scheduled'         => 'Scheduled',
    'status'            => 'Status',
    'live'              => 'Live',
    'draft'             => 'Draft',
];
