<?php

return [
    'global' => 'Global',
    'website'   => 'Club Websites'
];
