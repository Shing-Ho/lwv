<?php

return [
    'clubs'      => [
        'manage'
    ],
    'websites'      => [
        'manage'
    ],
    'documents' => [
        'private'
    ],
];
