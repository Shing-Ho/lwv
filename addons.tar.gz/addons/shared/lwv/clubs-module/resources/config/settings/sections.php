<?php

return [
    [
        'tabs' => [
            'global'    => [
                'title'  => 'lwv.module.clubs::tab.global',
                'fields' => [
                    'module_root',
                ]
            ],
            'website' => [
                'title'  => 'lwv.module.clubs::tab.website',
                'fields' => [
                    'website_footer',
                ]
            ]
        ]
    ]
];