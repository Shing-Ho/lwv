<?php namespace Lwv\ClubsModule\Document;

use Anomaly\Streams\Platform\Entry\EntryCollection;

class DocumentCollection extends EntryCollection
{

}
