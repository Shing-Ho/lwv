<?php namespace Lwv\ClubsModule\Document\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryInterface;

interface DocumentInterface extends EntryInterface
{

}
