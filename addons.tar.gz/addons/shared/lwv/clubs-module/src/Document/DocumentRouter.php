<?php namespace Lwv\ClubsModule\Document;

use Anomaly\Streams\Platform\Entry\EntryRouter;

class DocumentRouter extends EntryRouter
{

}
