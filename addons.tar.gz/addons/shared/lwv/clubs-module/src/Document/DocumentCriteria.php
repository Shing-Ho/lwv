<?php namespace Lwv\ClubsModule\Document;

use Anomaly\Streams\Platform\Entry\EntryCriteria;

class DocumentCriteria extends EntryCriteria
{

}
