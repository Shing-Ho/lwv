<?php namespace Lwv\ClubsModule\Document;

use Anomaly\Streams\Platform\Entry\EntryPresenter;

class DocumentPresenter extends EntryPresenter
{

}
