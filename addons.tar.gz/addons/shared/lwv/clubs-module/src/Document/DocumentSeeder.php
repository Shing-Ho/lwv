<?php namespace Lwv\ClubsModule\Document;

use Anomaly\Streams\Platform\Database\Seeder\Seeder;

class DocumentSeeder extends Seeder
{

    /**
     * Run the seeder.
     */
    public function run()
    {
        //
    }
}
