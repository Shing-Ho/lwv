<?php namespace Lwv\ClubsModule\Photo;

use Lwv\ClubsModule\Photo\Contract\PhotoInterface;
use Anomaly\Streams\Platform\Model\Clubs\ClubsPhotosEntryModel;

class PhotoModel extends ClubsPhotosEntryModel implements PhotoInterface
{

}
