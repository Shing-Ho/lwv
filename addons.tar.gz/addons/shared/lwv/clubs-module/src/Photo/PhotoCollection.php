<?php namespace Lwv\ClubsModule\Photo;

use Anomaly\Streams\Platform\Entry\EntryCollection;

class PhotoCollection extends EntryCollection
{

}
