<?php namespace Lwv\ClubsModule\Photo;

use Anomaly\Streams\Platform\Entry\EntryRouter;

class PhotoRouter extends EntryRouter
{

}
