<?php namespace Lwv\ClubsModule\Photo;

use Anomaly\Streams\Platform\Entry\EntryPresenter;

class PhotoPresenter extends EntryPresenter
{

}
