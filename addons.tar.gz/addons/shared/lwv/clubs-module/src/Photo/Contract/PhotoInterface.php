<?php namespace Lwv\ClubsModule\Photo\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryInterface;

interface PhotoInterface extends EntryInterface
{

}
