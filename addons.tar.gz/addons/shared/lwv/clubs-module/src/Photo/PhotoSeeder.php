<?php namespace Lwv\ClubsModule\Photo;

use Anomaly\Streams\Platform\Database\Seeder\Seeder;

class PhotoSeeder extends Seeder
{

    /**
     * Run the seeder.
     */
    public function run()
    {
        //
    }
}
