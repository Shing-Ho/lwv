<?php namespace Lwv\ClubsModule\Photo;

use Anomaly\Streams\Platform\Entry\EntryCriteria;

class PhotoCriteria extends EntryCriteria
{

}
