<?php namespace Lwv\ClubsModule\Header;

use Anomaly\Streams\Platform\Entry\EntryRouter;

class HeaderRouter extends EntryRouter
{

}
