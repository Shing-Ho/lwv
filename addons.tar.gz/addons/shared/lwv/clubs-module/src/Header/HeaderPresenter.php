<?php namespace Lwv\ClubsModule\Header;

use Anomaly\Streams\Platform\Entry\EntryPresenter;

class HeaderPresenter extends EntryPresenter
{

}
