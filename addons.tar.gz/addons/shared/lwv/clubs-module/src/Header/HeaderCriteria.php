<?php namespace Lwv\ClubsModule\Header;

use Anomaly\Streams\Platform\Entry\EntryCriteria;

class HeaderCriteria extends EntryCriteria
{

}
