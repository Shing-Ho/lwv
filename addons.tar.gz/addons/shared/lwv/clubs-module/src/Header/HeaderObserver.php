<?php namespace Lwv\ClubsModule\Header;

use Anomaly\Streams\Platform\Entry\EntryObserver;

class HeaderObserver extends EntryObserver
{

}
