<?php namespace Lwv\ClubsModule\Header;

use Anomaly\Streams\Platform\Database\Seeder\Seeder;

class HeaderSeeder extends Seeder
{

    /**
     * Run the seeder.
     */
    public function run()
    {
        //
    }
}
