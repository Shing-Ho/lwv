<?php namespace Lwv\ClubsModule\Header;

use Anomaly\Streams\Platform\Entry\EntryCollection;

class HeaderCollection extends EntryCollection
{

}
