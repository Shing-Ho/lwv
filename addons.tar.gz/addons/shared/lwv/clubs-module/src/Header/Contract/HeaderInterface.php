<?php namespace Lwv\ClubsModule\Header\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryInterface;

interface HeaderInterface extends EntryInterface
{

}
