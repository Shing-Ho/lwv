<?php namespace Lwv\ClubsModule\Header;

use Lwv\ClubsModule\Header\Contract\HeaderInterface;
use Anomaly\Streams\Platform\Model\Clubs\ClubsHeadersEntryModel;

class HeaderModel extends ClubsHeadersEntryModel implements HeaderInterface
{

}
