<?php namespace Lwv\ClubsModule\Club\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryInterface;

interface ClubInterface extends EntryInterface
{

}
