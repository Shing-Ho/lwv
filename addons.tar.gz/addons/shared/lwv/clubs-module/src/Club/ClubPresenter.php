<?php namespace Lwv\ClubsModule\Club;

use Anomaly\Streams\Platform\Entry\EntryPresenter;

class ClubPresenter extends EntryPresenter
{

}
