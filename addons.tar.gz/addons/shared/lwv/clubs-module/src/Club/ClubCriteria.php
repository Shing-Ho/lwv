<?php namespace Lwv\ClubsModule\Club;

use Anomaly\Streams\Platform\Entry\EntryCriteria;

class ClubCriteria extends EntryCriteria
{

}
