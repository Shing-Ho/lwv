<?php namespace Lwv\ClubsModule\Club;

use Anomaly\Streams\Platform\Entry\EntryObserver;

class ClubObserver extends EntryObserver
{

}
