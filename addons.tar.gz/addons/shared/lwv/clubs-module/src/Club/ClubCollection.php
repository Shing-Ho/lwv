<?php namespace Lwv\ClubsModule\Club;

use Anomaly\Streams\Platform\Entry\EntryCollection;

class ClubCollection extends EntryCollection
{

}
