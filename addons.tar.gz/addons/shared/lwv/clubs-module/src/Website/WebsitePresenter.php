<?php namespace Lwv\ClubsModule\Website;

use Anomaly\Streams\Platform\Entry\EntryPresenter;

class WebsitePresenter extends EntryPresenter
{

}
