<?php namespace Lwv\ClubsModule\Website;

use Anomaly\Streams\Platform\Entry\EntryObserver;

class WebsiteObserver extends EntryObserver
{

}
