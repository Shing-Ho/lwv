<?php namespace Lwv\ClubsModule\Website;

use Lwv\ClubsModule\Website\Contract\WebsiteInterface;
use Anomaly\Streams\Platform\Model\Clubs\ClubsWebsitesEntryModel;

class WebsiteModel extends ClubsWebsitesEntryModel implements WebsiteInterface
{

}
