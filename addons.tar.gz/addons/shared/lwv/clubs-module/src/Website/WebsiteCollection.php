<?php namespace Lwv\ClubsModule\Website;

use Anomaly\Streams\Platform\Entry\EntryCollection;

class WebsiteCollection extends EntryCollection
{

}
