<?php namespace Lwv\ClubsModule\Website;

use Anomaly\Streams\Platform\Database\Seeder\Seeder;

class WebsiteSeeder extends Seeder
{

    /**
     * Run the seeder.
     */
    public function run()
    {
        //
    }
}
