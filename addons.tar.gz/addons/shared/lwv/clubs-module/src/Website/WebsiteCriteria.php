<?php namespace Lwv\ClubsModule\Website;

use Anomaly\Streams\Platform\Entry\EntryCriteria;

class WebsiteCriteria extends EntryCriteria
{

}
