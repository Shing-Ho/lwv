<?php namespace Lwv\ClubsModule\Post;

use Anomaly\Streams\Platform\Entry\EntryCriteria;

class PostCriteria extends EntryCriteria
{

}
