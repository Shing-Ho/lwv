<?php namespace Lwv\ClubsModule\Post;

use Anomaly\Streams\Platform\Database\Seeder\Seeder;

class PostSeeder extends Seeder
{

    /**
     * Run the seeder.
     */
    public function run()
    {
        //
    }
}
