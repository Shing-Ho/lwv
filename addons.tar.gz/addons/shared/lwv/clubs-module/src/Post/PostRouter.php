<?php namespace Lwv\ClubsModule\Post;

use Anomaly\Streams\Platform\Entry\EntryRouter;

class PostRouter extends EntryRouter
{

}
