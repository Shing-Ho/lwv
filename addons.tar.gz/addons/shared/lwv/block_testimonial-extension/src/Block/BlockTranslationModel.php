<?php namespace Lwv\BlockTestimonialExtension\Block;

use Illuminate\Database\Eloquent\Model;

class BlockTranslationModel extends Model
{
    protected $table = 'block_testimonial_blocks_translations';
}
