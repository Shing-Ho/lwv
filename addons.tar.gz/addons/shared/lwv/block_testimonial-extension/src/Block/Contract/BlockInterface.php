<?php namespace Lwv\BlockTestimonialExtension\Block\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryInterface;

interface BlockInterface extends EntryInterface
{

}
