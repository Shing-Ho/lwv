<?php namespace Lwv\BlockTestimonialExtension\Block;

use Anomaly\Streams\Platform\Entry\EntryCollection;

class BlockCollection extends EntryCollection
{

}
