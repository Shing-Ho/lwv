<?php

return [
    'blocks' => [
        'name' => 'Blocks'
    ],
];