<?php

return [
    'title'       => 'Block Type (Testimonial)',
    'name'        => 'Block Type (Testimonial)',
    'description' => 'Build testimonial slider blocks from the Testimonials data stream',
];
