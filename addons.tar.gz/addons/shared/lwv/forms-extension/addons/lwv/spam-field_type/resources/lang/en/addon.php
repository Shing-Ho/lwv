<?php

return [
    'title'       => 'Spam',
    'name'        => 'Spam Field Type',
    'description' => 'Provides spam control field for forms'
];
