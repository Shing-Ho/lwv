<?php namespace Lwv\SpamFieldType;

use Anomaly\Streams\Platform\Addon\AddonServiceProvider;

/**
 * Class SpamFieldTypeServiceProvider
 */
class SpamFieldTypeServiceProvider extends AddonServiceProvider
{

    /**
     * The addon routes.
     *
     * @var array
     */
    protected $routes = [];

}
