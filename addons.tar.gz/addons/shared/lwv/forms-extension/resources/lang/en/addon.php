<?php

return [
    'title'       => 'Forms',
    'name'        => 'Forms Extension',
    'description' => 'Provides custom forms and validation routines'
];
