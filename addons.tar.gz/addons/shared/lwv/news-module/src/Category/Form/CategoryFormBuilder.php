<?php namespace Lwv\NewsModule\Category\Form;

use Anomaly\Streams\Platform\Ui\Form\FormBuilder;

/**
 * Class CategoryFormBuilder
 */
class CategoryFormBuilder extends FormBuilder
{

}
