<?php namespace Lwv\NewsModule\Entry\Form;

use Anomaly\Streams\Platform\Ui\Form\FormBuilder;

/**
 * Class EntryFormBuilder
 */
class EntryFormBuilder extends FormBuilder
{

}
