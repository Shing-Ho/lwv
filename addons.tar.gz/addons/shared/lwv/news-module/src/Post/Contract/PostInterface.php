<?php namespace Lwv\NewsModule\Post\Contract;

use Lwv\NewsModule\Category\Contract\CategoryInterface;
use Lwv\NewsModule\Type\Contract\TypeInterface;
use Anomaly\Streams\Platform\Entry\Contract\EntryInterface;
use Carbon\Carbon;
use Symfony\Component\HttpFoundation\Response;

/**
 * Interface PostInterface
 */
interface PostInterface extends EntryInterface
{

    /**
     * Return the post's path.
     *
     * @return string
     */
    public function path();

    /**
     * Get the string ID.
     *
     * @return string
     */
    public function getStrId();

    /**
     * Get the tags.
     *
     * @return array
     */
    public function getTags();

    /**
     * Get the slug.
     *
     * @return string
     */
    public function getSlug();

    /**
     * Get the type.
     *
     * @return null|TypeInterface
     */
    public function getType();

    /**
     * Get the type name.
     *
     * @return string
     */
    public function getTypeName();

    /**
     * Get the type description.
     *
     * @return string
     */
    public function getTypeDescription();

    /**
     * Get the category.
     *
     * @return null|CategoryInterface
     */
    public function getCategory();

    /**
     * Get the related entry.
     *
     * @return EntryInterface
     */
    public function getEntry();

    /**
     * Get the related entry's ID.
     *
     * @return null|int
     */
    public function getEntryId();

    /**
     * Get the meta title.
     *
     * @return string
     */
    public function getMetaTitle();

    /**
     * Get the meta keywords.
     *
     * @return array
     */
    public function getMetaKeywords();

    /**
     * Get the meta description.
     *
     * @return string
     */
    public function getMetaDescription();

    /**
     * Return the publish at date.
     *
     * @return Carbon
     */
    public function getPublishAt();

    /**
     * Alias for getPublishAt()
     *
     * @return Carbon
     */
    public function getDate();

    /**
     * Return if the post is live or not.
     *
     * @return bool
     */
    public function isLive();

    /**
     * Return if the post is expired or not.
     *
     * @return bool
     */
    public function isExpired();

    /**
     * Return if the post is scheduled or not.
     *
     * @return bool
     */
    public function isScheduled();

    /**
     * Get the enabled flag.
     *
     * @return bool
     */
    public function isEnabled();

    /**
     * Get the content.
     *
     * @return null|string
     */
    public function getContent();

    /**
     * Set the content.
     *
     * @param $content
     * @return $this
     */
    public function setContent($content);

    /**
     * Get the response.
     *
     * @return Response|null
     */
    public function getResponse();

    /**
     * Set the response.
     *
     * @param $response
     * @return $this
     */
    public function setResponse(Response $response);
}
