<?php

return [
    'Lwv\NewsModule\Post\PostModel' => [
        'type' => 'posts',
        'namespace' => 'news',
        'stream' => 'posts',
        'title' => 'title',
        'content' => 'news_body',
        'path' => 'path'
    ]
];