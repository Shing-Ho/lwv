<?php

return [
    'posts'      => [
        'manage'
    ],
    'categories' => [
        'manage'
    ],
    'types'      => [
        'manage'
    ],
    'fields'     => [
        'manage'
    ]
];
