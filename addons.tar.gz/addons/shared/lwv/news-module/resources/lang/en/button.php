<?php

return [
    'new_post'     => 'New Post',
    'new_category' => 'New Category',
    'new_type'     => 'New Type',
    'new_field'    => 'New Field',
    'add_field'    => 'Add Field',
];
