<?php

return [
    'posts'      => [
        'name' => 'Posts'
    ],
    'post_types' => [
        'name' => 'Post Types'
    ],
    'categories' => [
        'name' => 'Categories'
    ],
    'types' => [
        'name' => 'Types'
    ]
];