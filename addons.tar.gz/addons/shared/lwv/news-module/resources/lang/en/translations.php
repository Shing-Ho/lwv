<?php

return [
    'categories'       => 'Categories',
    'read more'        => 'Read More',
    'featured news' => 'Featured News',
    'archives' => 'Archives'
];