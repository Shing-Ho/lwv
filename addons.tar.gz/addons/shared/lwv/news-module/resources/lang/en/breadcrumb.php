<?php

return [
    'posts'  => 'News',
    'fields' => 'Fields',
    'tagged' => 'Tagged ":tag"'
];
