<?php

return [
    'search_results' => 'Search Results',
    'search' => 'Search',
];
