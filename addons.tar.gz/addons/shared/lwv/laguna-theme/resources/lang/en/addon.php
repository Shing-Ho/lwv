<?php

return [
    'title'       => 'Laguna Woods Village',
    'name'        => 'Laguna Woods Village Theme',
    'description' => 'Laguna Woods Village Theme',
];
