<?php namespace Lwv\LagunaTheme;

use Anomaly\Streams\Platform\Addon\Theme\Theme;

/**
 * Class LagunaTheme
 *
 * @link          http://www.pyrocms.com/streams-platform
 * @author        Ryan McDaniel <ryan@itinnovative.com>
 * @package       Lwv\LagunaTheme
 */
class LagunaTheme extends Theme
{
    protected $admin = false;
}
