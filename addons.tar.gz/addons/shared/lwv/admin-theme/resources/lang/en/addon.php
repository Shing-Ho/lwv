<?php

return [
    'title'       => 'Laguna Woods Village',
    'name'        => 'Laguna Woods Village Admin Theme',
    'description' => 'Laguna Woods Village Admin Theme',
];
