<?php

return [
    'help'      => 'Help',
    'search'    => 'Search',
    'logout'    => 'Logout',
    'view_site' => 'View Site',
    'title'     => 'Control Panel'
];
