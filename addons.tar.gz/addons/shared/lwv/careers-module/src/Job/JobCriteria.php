<?php namespace Lwv\CareersModule\Job;

use Anomaly\Streams\Platform\Entry\EntryCriteria;

class JobCriteria extends EntryCriteria
{

}
