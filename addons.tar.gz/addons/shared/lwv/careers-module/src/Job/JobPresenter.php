<?php namespace Lwv\CareersModule\Job;

use Anomaly\Streams\Platform\Entry\EntryPresenter;

class JobPresenter extends EntryPresenter
{

}
