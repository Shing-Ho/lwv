<?php namespace Lwv\CareersModule\Job\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryInterface;

interface JobInterface extends EntryInterface
{

}
