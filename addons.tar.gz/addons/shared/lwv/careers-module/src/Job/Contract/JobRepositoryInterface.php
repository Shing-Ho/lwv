<?php namespace Lwv\CareersModule\Job\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryRepositoryInterface;

interface JobRepositoryInterface extends EntryRepositoryInterface
{

}
