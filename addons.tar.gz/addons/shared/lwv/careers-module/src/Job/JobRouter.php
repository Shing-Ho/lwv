<?php namespace Lwv\CareersModule\Job;

use Anomaly\Streams\Platform\Entry\EntryRouter;

class JobRouter extends EntryRouter
{

}
