<?php namespace Lwv\CareersModule\Job;

use Anomaly\Streams\Platform\Entry\EntryObserver;

class JobObserver extends EntryObserver
{

}
