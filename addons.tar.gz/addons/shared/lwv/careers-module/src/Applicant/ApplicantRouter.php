<?php namespace Lwv\CareersModule\Applicant;

use Anomaly\Streams\Platform\Entry\EntryRouter;

class ApplicantRouter extends EntryRouter
{

}
