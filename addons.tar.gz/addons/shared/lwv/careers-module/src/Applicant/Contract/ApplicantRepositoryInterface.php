<?php namespace Lwv\CareersModule\Applicant\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryRepositoryInterface;

interface ApplicantRepositoryInterface extends EntryRepositoryInterface
{

}
