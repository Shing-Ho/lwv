<?php namespace Lwv\CareersModule\Applicant\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryInterface;

interface ApplicantInterface extends EntryInterface
{

}
