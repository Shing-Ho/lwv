<?php namespace Lwv\CareersModule\Applicant;

use Anomaly\Streams\Platform\Entry\EntryObserver;

class ApplicantObserver extends EntryObserver
{

}
