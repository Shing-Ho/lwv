<?php namespace Lwv\CareersModule\Applicant;

use Anomaly\Streams\Platform\Entry\EntryCriteria;

class ApplicantCriteria extends EntryCriteria
{

}
