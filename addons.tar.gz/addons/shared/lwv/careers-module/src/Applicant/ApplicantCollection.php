<?php namespace Lwv\CareersModule\Applicant;

use Anomaly\Streams\Platform\Entry\EntryCollection;

class ApplicantCollection extends EntryCollection
{

}
