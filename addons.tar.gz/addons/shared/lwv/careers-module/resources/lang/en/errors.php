<?php

return [
    'form_invalid_name'       => 'Please enter your name',
    'form_invalid_email'      => 'Please enter a valid email address',
    'form_invalid_phone'      => 'Please enter a valid phone number',
];
