<?php

return [
    'careers'     => [
        'name'   => 'Careers',
        'option' => [
            'manage'   => 'Can manage careers content.',
        ]
    ]
];
