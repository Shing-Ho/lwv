<?php

return [
    'new_job' => 'New Job',
];
