<?php

return [
    'active' => 'Active Jobs',
    'archived' => 'Archived Jobs',
];
