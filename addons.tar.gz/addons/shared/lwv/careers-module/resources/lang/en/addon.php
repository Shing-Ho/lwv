<?php

return [
    'title'       => 'Careers',
    'name'        => 'Careers Module',
    'description' => 'Provides career functionality',
    'section'     => [
        'jobs'    => 'Jobs',
        'applicants'    => 'Applicants',
    ]
];
