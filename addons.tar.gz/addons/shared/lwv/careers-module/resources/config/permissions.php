<?php

return [
    'careers'      => [
        'manage'
    ],
];
