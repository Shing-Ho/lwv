<?php namespace Lwv\BlockSliderExtension\Block\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryInterface;

interface BlockInterface extends EntryInterface
{

}
