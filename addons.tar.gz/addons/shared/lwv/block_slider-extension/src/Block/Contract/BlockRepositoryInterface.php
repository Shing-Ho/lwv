<?php namespace Lwv\BlockSliderExtension\Block\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryRepositoryInterface;

interface BlockRepositoryInterface extends EntryRepositoryInterface
{

}
