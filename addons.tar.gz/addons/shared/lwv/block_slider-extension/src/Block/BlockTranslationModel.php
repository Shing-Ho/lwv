<?php namespace Lwv\BlockSliderExtension\Block;

use Illuminate\Database\Eloquent\Model;

class BlockTranslationModel extends Model
{
    protected $table = 'block_slider_blocks_translations';
}
