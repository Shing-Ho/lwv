<?php namespace Lwv\BlockSliderExtension\Block;

use Anomaly\Streams\Platform\Entry\EntryPresenter;

class BlockPresenter extends EntryPresenter
{

}
