<?php namespace Lwv\BlockSliderExtension\Image;

use Anomaly\Streams\Platform\Entry\EntryPresenter;

class ImagePresenter extends EntryPresenter
{

}
