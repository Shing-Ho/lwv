<?php namespace Lwv\BlockSliderExtension\Image;

use Illuminate\Database\Eloquent\Model;

class ImageTranslationModel extends Model
{
    protected $table = 'block_slider_images_translations';
}
