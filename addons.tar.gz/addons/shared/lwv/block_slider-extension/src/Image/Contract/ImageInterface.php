<?php namespace Lwv\BlockSliderExtension\Image\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryInterface;

interface ImageInterface extends EntryInterface
{

}
