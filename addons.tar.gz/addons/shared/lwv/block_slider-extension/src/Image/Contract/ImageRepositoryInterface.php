<?php namespace Lwv\BlockSliderExtension\Image\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryRepositoryInterface;

interface ImageRepositoryInterface extends EntryRepositoryInterface
{

}
