<?php namespace Lwv\BlockSliderExtension\Image;

use Anomaly\Streams\Platform\Entry\EntryCollection;

class ImageCollection extends EntryCollection
{

}
