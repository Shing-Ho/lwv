<?php

return [
    'title'       => 'Block Type (Slider)',
    'name'        => 'Block Type (Slider)',
    'description' => 'Build slider blocks in a variety of layouts',
];
