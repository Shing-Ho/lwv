<?php

return [
    'blocks' => [
        'name' => 'Blocks'
    ],
    'images' => [
        'name' => 'Block Images'
    ],
];