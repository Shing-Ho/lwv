<?php namespace Lwv\BlockTextExtension\Block;

use Illuminate\Database\Eloquent\Model;

class BlockTranslationModel extends Model
{
    protected $table = 'block_text_blocks_translations';
}
