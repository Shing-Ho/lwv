<?php namespace Lwv\BlockTextExtension\Block\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryInterface;

interface BlockInterface extends EntryInterface
{

}
