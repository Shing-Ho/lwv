<?php namespace Lwv\BlockTextExtension\Block;

use Lwv\BlockTextExtension\Block\Contract\BlockInterface;
use Anomaly\Streams\Platform\Model\BlockText\BlockTextBlocksEntryModel;

class BlockModel extends BlockTextBlocksEntryModel implements BlockInterface
{
}
