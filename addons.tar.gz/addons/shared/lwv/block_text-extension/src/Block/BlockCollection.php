<?php namespace Lwv\BlockTextExtension\Block;

use Anomaly\Streams\Platform\Entry\EntryCollection;

class BlockCollection extends EntryCollection
{

}
