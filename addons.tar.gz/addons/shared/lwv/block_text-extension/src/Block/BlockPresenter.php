<?php namespace Lwv\BlockTextExtension\Block;

use Anomaly\Streams\Platform\Entry\EntryPresenter;

class BlockPresenter extends EntryPresenter
{

}
