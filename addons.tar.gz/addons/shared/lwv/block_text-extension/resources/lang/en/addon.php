<?php

return [
    'title'       => 'Block Type (Text)',
    'name'        => 'Block Type (Text)',
    'description' => 'Simple text block allowing for a Title and Body',
];
