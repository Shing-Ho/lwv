<?php

return [
    'title'       => 'Block Type (Image)',
    'name'        => 'Block Type (Image)',
    'description' => 'Simple image block allowing for Images and Body',
];
