<?php namespace Lwv\BlockImageExtension\Block;

use Lwv\BlockImageExtension\Block\Contract\BlockInterface;
use Anomaly\Streams\Platform\Model\BlockImage\BlockImageBlocksEntryModel;

class BlockModel extends BlockImageBlocksEntryModel implements BlockInterface
{
}
