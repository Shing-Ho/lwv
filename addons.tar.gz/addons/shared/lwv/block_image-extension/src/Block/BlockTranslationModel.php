<?php namespace Lwv\BlockImageExtension\Block;

use Illuminate\Database\Eloquent\Model;

class BlockTranslationModel extends Model
{
    protected $table = 'block_image_blocks_translations';
}
