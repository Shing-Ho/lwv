<?php namespace Lwv\BlockImageExtension\Block\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryInterface;

interface BlockInterface extends EntryInterface
{

}
