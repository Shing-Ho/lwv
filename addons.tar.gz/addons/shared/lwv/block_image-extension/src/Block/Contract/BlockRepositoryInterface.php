<?php namespace Lwv\BlockImageExtension\Block\Contract;

use Anomaly\Streams\Platform\Entry\Contract\EntryRepositoryInterface;

interface BlockRepositoryInterface extends EntryRepositoryInterface
{

}
